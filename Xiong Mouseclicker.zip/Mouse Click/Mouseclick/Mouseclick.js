//FPS and Variables Lab
//Created by Yeng Xiong

let clr;
let fps = 30;
let value;
let altClr;
let white;
let r = 0;
let g = 0;
let b = 0;

function setup() {
  // put setup code here

    createCanvas(400, 400);
    background(80);
    colorMode(RGB, 255, 255, 255, 1);
    frameRate(fps);
    clr = color(51, 112, 196, 1); //cerulean blue
    value = clr;
    white = color(255, 255, 255, 1);
}

function draw() {
    // put drawing code here
    strokeWeight(5);
    fill(value);

    rect(25, 25, 50, 50);
    altClr = color(r, g, b, 1);
    fill(altClr);
    rect(325, 25, 50, 50);

    yPos = 10;
}

function mouseClicked() {
    if (mouseX <= 75 && mouseY <= 75 && mouseX >= 25 && mouseY >= 25) {
        if (value === clr) {
            value = white;
        }
        else {
            value = clr;
        }
        background(80);
    }
    else {
        if (value === white) {
            fill(altClr);
            rect(mouseX, mouseY, 20, 20);
        }
    }
}

function keyPressed() {
    if (value === clr) {
        r = r + 10;
        b = b + 10;
    }
    else if (mouseX <= 75 && mouseY <= 75 && mouseX >= 25 && mouseY >= 25) {
        r = 0;
        g = 0;
        b = 0;
    }
    else {
        g = g + 10;
        b = b + 10;
    }
}