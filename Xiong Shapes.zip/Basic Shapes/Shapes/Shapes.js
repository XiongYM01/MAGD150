//Shapes Lab
//Created by Yeng Xiong

function setup() {
  // put setup code here
    createCanvas(400, 400);
    colorMode(RGB, 255, 255, 255, 1);
    background(80);
    
}

function draw() {
  // put drawing code here
    strokeWeight(4);
    stroke(70, 39, 39, 0.5);
    fill(154, 112, 75, 0.1);
    //cones
    triangle(50, 250, 80, 250, 65, 350);
    triangle(350, 250, 320, 250, 335, 350);

    triangle(50, 90, 80, 90, 65, 40);
    triangle(350, 90, 320, 90, 335, 40);

    //strawberry ice cream
    stroke(229, 70, 230, 0.8);
    fill(229, 137, 232, 0.2);
    arc(65, 225, 60, 60, PI - QUARTER_PI, PI + PI + QUARTER_PI, CHORD);
    arc(335, 225, 60, 60, PI - QUARTER_PI, PI + PI + QUARTER_PI, CHORD);

    arc(65, 100, 30, 30, 0 - QUARTER_PI, PI + QUARTER_PI, CHORD);
    arc(335, 100, 30, 30, 0 - QUARTER_PI, PI + QUARTER_PI, CHORD);

    //rainbows
    noFill();
    stroke(255, 0, 0, 1);
    strokeWeight(4);
    beginShape();
    curveVertex(0, 220);
    curveVertex(125, 200);
    curveVertex(200, 150);
    curveVertex(275, 200);
    curveVertex(400, 220);
    endShape();

    //orange
    stroke(255, 119, 0, 0.9);
    beginShape();
    curveVertex(0, 225);
    curveVertex(125, 205);
    curveVertex(200, 155);
    curveVertex(275, 205);
    curveVertex(400, 225);
    endShape();

    //yellow
    stroke(255, 255, 0, 0.8);
    beginShape();
    curveVertex(0, 230);
    curveVertex(125, 210);
    curveVertex(200, 160);
    curveVertex(275, 210);
    curveVertex(400, 230);
    endShape();

    //green
    stroke(0, 255, 0, 0.7);
    beginShape();
    curveVertex(0, 235);
    curveVertex(125, 215);
    curveVertex(200, 165);
    curveVertex(275, 215);
    curveVertex(400, 235);
    endShape();

    //blue
    stroke(0, 0, 255, 0.6);
    beginShape();
    curveVertex(0, 240);
    curveVertex(125, 220);
    curveVertex(200, 170);
    curveVertex(275, 220);
    curveVertex(400, 240);
    endShape();

    //purple
    stroke(255, 0, 255, 0.5);
    beginShape();
    curveVertex(0, 245);
    curveVertex(125, 225);
    curveVertex(200, 175);
    curveVertex(275, 225);
    curveVertex(400, 245);
    endShape();
}