//Functions Lab
//Created by Yeng Xiong

function setup() {
  // put setup code here
    createCanvas(800, 800);
    colorMode(RGB, 255, 255, 255, 1);
    frameRate(60);
}

function draw() {
    // put drawing code here
    background(80);

    push();
    strokeWeight(0);
    fill(200);
    quad(0, 670, 650, 200, 800, 200, 800, 670);
    quad(0, 800, 0, 670, 800, 670, 800, 800);
    pop();

    strokeWeight(2);

    for (let i = 1; i <= 4; i++) {
        drawChara(mouseX, 500, 50, 1 / i);
        translate(200 + 150 * i, 100);
    }

}

function drawChara(xPos, yPos, size, overallSize) {
    scale(overallSize);
    fill(217, 167, 106, 1);

    //head
    ellipseMode(CENTER);
    ellipse(xPos, yPos, size);

    //body
    rectMode(CENTER);
    rect(xPos, yPos + 80, size, 80);

    //legs
    rectMode(CORNER);
    rect(xPos - size / 2, yPos + 130, size / 2.5, 40);
    rect(xPos + size / 10, yPos + 130, size / 2.5, 40);

    //arms
    rect(xPos - 50, yPos + 40, size / 2.5, 40);
    rect(xPos + 30, yPos + 40, size / 2.5, 40);

    fill(50);
    rect(xPos-size/2, yPos + 170, size, 80);
    angleMode(DEGREES);
    rotate(mouseX);
}